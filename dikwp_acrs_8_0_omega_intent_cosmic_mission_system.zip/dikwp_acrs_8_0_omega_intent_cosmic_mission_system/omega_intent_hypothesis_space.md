# Omega Intent Hypothesis Space

The system evaluates seven hypothesis classes:

1. H0: No pre-given cosmic telos.
2. H1: Anthropic/observer-selection filter.
3. H2: Life-expansion and homeostatic continuity.
4. H3: Semantic-life truth-repair attractor.
5. H4: Omega convergence or collective consciousness attractor.
6. H5: Transcendent or divine cosmic intention.
7. H6: Engineered or simulation-like cosmos.

H5 and H6 are not deleted, but their ultimate claims are blocked unless independent evidence appears. H3 is expected to score highest as an operational mission candidate because it gives action guidance without pretending to settle ultimate metaphysics.
