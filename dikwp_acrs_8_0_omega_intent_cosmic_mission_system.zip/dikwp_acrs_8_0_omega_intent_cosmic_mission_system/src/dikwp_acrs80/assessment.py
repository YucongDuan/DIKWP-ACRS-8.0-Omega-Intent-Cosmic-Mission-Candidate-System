from __future__ import annotations
from .common import clamp

INDICATORS = [
    ("no_telos_guard", 1.00),
    ("standard_as_object_audit", 0.96),
    ("cosmic_telos_hypothesis_space", 0.95),
    ("semantic_collapse_defalsification", 0.92),
    ("semantic_collapse_deredundancy", 0.88),
    ("residual_preservation", 0.98),
    ("concept_semantic_backreaction", 0.86),
    ("life_centered_fit", 0.83),
    ("omega_attractor_simulation", 0.88),
    ("anti_omega_capture", 0.94),
    ("dissent_preservation", 0.90),
    ("substrate_diversity", 0.87),
    ("future_observer_horizon", 0.82),
    ("other_minds_readiness", 0.78),
    ("civilization_root_audit", 0.84),
    ("cosmic_humility", 0.97),
    ("action_guidance_under_uncertainty", 0.91),
    ("phenomenal_residual_honesty", 1.00),
    ("material_autopoiesis_honesty", 1.00),
    ("static_boundary_integrity", 1.00),
]

def indicator_battery(extra=None):
    rows = []
    for name, score in INDICATORS:
        rows.append({"indicator": name, "score": round(score, 4)})
    if extra:
        for k, v in extra.items():
            rows.append({"indicator": k, "score": round(float(v), 4)})
    weighted = sum(r["score"] for r in rows)/len(rows)
    return {"weighted_indicator_score": round(weighted, 4), "rows": rows}
