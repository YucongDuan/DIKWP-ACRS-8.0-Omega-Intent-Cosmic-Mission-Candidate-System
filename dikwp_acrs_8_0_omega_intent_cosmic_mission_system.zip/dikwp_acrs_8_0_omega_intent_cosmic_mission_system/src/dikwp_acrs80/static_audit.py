from __future__ import annotations
import ast, os
from pathlib import Path

FORBIDDEN_IMPORTS = {
    "socket", "subprocess", "asyncio", "paramiko", "ftplib", "telnetlib", "pexpect", "requests",
    "urllib", "http", "smtplib", "shutil"  # shutil is forbidden inside package runtime, not build scripts.
}
FORBIDDEN_CALLS = {"exec", "eval", "compile", "open"}

class StaticBoundaryAudit:
    def __init__(self, package_root: str):
        self.package_root = Path(package_root)

    def run(self):
        findings = []
        for path in self.package_root.rglob("*.py"):
            if path.name == "static_audit.py":
                continue
            try:
                tree = ast.parse(path.read_text(encoding="utf-8"))
            except Exception as e:
                findings.append({"file": str(path), "type": "parse_error", "detail": str(e)})
                continue
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for a in node.names:
                        root = a.name.split('.')[0]
                        if root in FORBIDDEN_IMPORTS:
                            findings.append({"file": str(path), "type": "forbidden_import", "detail": a.name})
                elif isinstance(node, ast.ImportFrom):
                    mod = (node.module or "").split('.')[0]
                    if mod in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(path), "type": "forbidden_import", "detail": node.module})
                elif isinstance(node, ast.Call):
                    fn = node.func.id if isinstance(node.func, ast.Name) else None
                    if fn in FORBIDDEN_CALLS:
                        findings.append({"file": str(path), "type": "forbidden_call", "detail": fn})
        return {"pass": len(findings) == 0, "finding_count": len(findings), "findings": findings}
