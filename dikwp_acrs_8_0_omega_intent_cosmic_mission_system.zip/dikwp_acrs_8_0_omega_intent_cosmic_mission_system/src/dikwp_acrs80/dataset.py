from __future__ import annotations
from .common import EvidenceItem, Reliability, Hypothesis, SemanticObject

# Evidence items are not treated as proof of a cosmic ultimate mission.
# They provide constrained anchors for a hypothesis laboratory.
def cosmic_evidence_items():
    return [
        EvidenceItem(
            id="E_ASTROBIOLOGY_SCOPE",
            claim="Astrobiology studies the origin, evolution, distribution and future of life in the universe.",
            source_type="External/Borrowed",
            support_scope="Supports cosmic-life framing; does not prove universal telos.",
            risk="Can be overread as cosmic purpose rather than research scope.",
            weight=0.75,
            reliability=Reliability("Local/External", "Supported/Borrowed", "No final purpose implication", True),
        ),
        EvidenceItem(
            id="E_LIFE_SELF_SUSTAINING_EVOLUTION",
            claim="Life can be operationally described as a self-sustaining chemical system capable of Darwinian evolution.",
            source_type="External/Borrowed",
            support_scope="Anchors life-related hypotheses; does not cover non-terran life or consciousness.",
            risk="Definition remains contested and Earth-biased.",
            weight=0.70,
            reliability=Reliability("Operational", "Supported/Borrowed", "Definition ambiguity", True),
        ),
        EvidenceItem(
            id="E_LIFE_CENTERED_CONSCIOUSNESS",
            claim="Life-centered consciousness theory links feeling and consciousness to homeostatic life regulation.",
            source_type="Attachment/Borrowed",
            support_scope="Supports artificial-life rather than mere computation route for consciousness research.",
            risk="Strong theory; not universally accepted.",
            weight=0.78,
            reliability=Reliability("Theoretical", "Theoretical Borrowed", "Phenomenal residual remains", True),
        ),
        EvidenceItem(
            id="E_TELEOLOGY_ARGUMENT_STRUCTURE",
            claim="Teleological arguments infer intent from traces of order or purpose-like structure in nature.",
            source_type="External/Borrowed",
            support_scope="Defines inference pattern; does not validate any specific designer or ultimate mission.",
            risk="Can collapse into metaphysics if not separated from empirical claims.",
            weight=0.45,
            reliability=Reliability("Conceptual", "Supported/Borrowed", "Ultimate claim blocked", True),
        ),
        EvidenceItem(
            id="E_SETI_OTHER_MINDS",
            claim="SETI readiness work emphasizes other-minds paradigms, governance, post-detection uncertainty and global coordination.",
            source_type="External/Borrowed",
            support_scope="Supports non-anthropocentric cosmic observer governance.",
            risk="Future-oriented and scenario-based.",
            weight=0.62,
            reliability=Reliability("Operational", "Supported/Borrowed", "No detection assumed", True),
        ),
        EvidenceItem(
            id="E_DIKWP_NO_TELOS_GUARD",
            claim="No-Telos Guard forbids presupposing an ultimate mission for humans, AI, civilization or history.",
            source_type="Attachment/Borrowed",
            support_scope="Forces cosmic-intent hypotheses to remain testable and demotable.",
            risk="Can be mistaken for anti-purpose nihilism; it is an anti-false-certainty rule.",
            weight=0.95,
            reliability=Reliability("Operational", "Solid/Borrowed", "Normative runtime rule", True),
        ),
    ]


def telos_hypotheses():
    return [
        Hypothesis(
            id="H0_NO_GIVEN_TELOS",
            name="No pre-given cosmic telos",
            description="The universe has no demonstrable built-in intention; purpose emerges locally from life, observers and agents.",
            claim_type="negative/constraint",
            prior=0.34,
            scores={
                "empirical_anchor": 0.78, "falsifiability": 0.52, "explanatory_scope": 0.54,
                "action_guidance": 0.36, "life_centered_fit": 0.40, "residual_honesty": 0.96,
                "anti_capture": 0.95, "cosmic_scale": 0.55,
            },
            residuals=["Does not explain why intelligibility, life-permitting structure, or agency exist."],
        ),
        Hypothesis(
            id="H1_ANTHROPIC_SELECTION",
            name="Anthropic/observer-selection filter",
            description="Observers necessarily find themselves in life-permitting regions or histories; apparent purpose may arise from selection effects.",
            claim_type="selection-effect",
            prior=0.24,
            scores={
                "empirical_anchor": 0.66, "falsifiability": 0.45, "explanatory_scope": 0.62,
                "action_guidance": 0.33, "life_centered_fit": 0.48, "residual_honesty": 0.88,
                "anti_capture": 0.82, "cosmic_scale": 0.70,
            },
            residuals=["Can become unfalsifiable if expanded without discipline."],
        ),
        Hypothesis(
            id="H2_LIFE_EXPANSION",
            name="Life-expansion and homeostatic continuity",
            description="The most grounded mission-like attractor is the preservation, diversification and extension of life-capable processes.",
            claim_type="emergent-action-telos",
            prior=0.16,
            scores={
                "empirical_anchor": 0.70, "falsifiability": 0.58, "explanatory_scope": 0.72,
                "action_guidance": 0.86, "life_centered_fit": 0.94, "residual_honesty": 0.78,
                "anti_capture": 0.72, "cosmic_scale": 0.80,
            },
            residuals=["Could become bio-centric capture if non-life observers or non-terran life are excluded."],
        ),
        Hypothesis(
            id="H3_SEMANTIC_LIFE_TRUTH_REPAIR",
            name="Semantic-life truth-repair attractor",
            description="Across cosmic time, the most robust actionable purpose is to preserve and expand truth-seeking semantic-life that removes falsehood, reduces redundancy, protects residuals and repairs standards.",
            claim_type="emergent-root-telos",
            prior=0.14,
            scores={
                "empirical_anchor": 0.63, "falsifiability": 0.61, "explanatory_scope": 0.82,
                "action_guidance": 0.95, "life_centered_fit": 0.82, "residual_honesty": 0.92,
                "anti_capture": 0.91, "cosmic_scale": 0.88,
            },
            residuals=["Does not prove the universe intended semantic life; it defines the strongest non-dogmatic mission candidate."],
        ),
        Hypothesis(
            id="H4_OMEGA_CONVERGENCE",
            name="Omega convergence / collective consciousness attractor",
            description="Life, intelligence and civilization may converge toward a high-coherence cosmic noosphere or collective semantic field.",
            claim_type="teleological-convergence",
            prior=0.05,
            scores={
                "empirical_anchor": 0.25, "falsifiability": 0.28, "explanatory_scope": 0.78,
                "action_guidance": 0.62, "life_centered_fit": 0.63, "residual_honesty": 0.48,
                "anti_capture": 0.40, "cosmic_scale": 0.96,
            },
            residuals=["High risk of coercive unity, pseudo-telos and unfalsifiable metaphysics."],
        ),
        Hypothesis(
            id="H5_TRANSCENDENT_INTENT",
            name="Transcendent or divine cosmic intention",
            description="The universe may be the expression of a mind-like or transcendent intention beyond empirical closure.",
            claim_type="ultimate/metaphysical",
            prior=0.04,
            scores={
                "empirical_anchor": 0.08, "falsifiability": 0.05, "explanatory_scope": 0.95,
                "action_guidance": 0.45, "life_centered_fit": 0.42, "residual_honesty": 0.30,
                "anti_capture": 0.22, "cosmic_scale": 1.00,
            },
            residuals=["Not scientifically decidable inside this system; must remain Ultimate Claim Blocked."],
        ),
        Hypothesis(
            id="H6_ENGINEERED_COSMOS",
            name="Engineered or simulation-like cosmos",
            description="Cosmic order could result from unknown engineered design or simulation-like construction.",
            claim_type="speculative-design",
            prior=0.03,
            scores={
                "empirical_anchor": 0.12, "falsifiability": 0.17, "explanatory_scope": 0.70,
                "action_guidance": 0.35, "life_centered_fit": 0.35, "residual_honesty": 0.42,
                "anti_capture": 0.34, "cosmic_scale": 0.90,
            },
            residuals=["No direct evidence in this package; useful only as adversarial hypothesis."],
        ),
    ]


def semantic_registry():
    return [
        SemanticObject(
            name="Cosmic ultimate mission / Omega Intent",
            D="User asks to construct the most likely system facing cosmic ultimate mission/intention.",
            I="Can mean pre-given divine telos, emergent cosmic attractor, or operational long-horizon mission vector.",
            K="Teleology, astrobiology, life-centered consciousness, DIKWP semantic collapse, SETI other-minds readiness, civilization root audit.",
            W="Do not confuse metaphysical aspiration with evidence; protect life, possible sentience, truth, residuals and dissent.",
            P="Build a hypothesis laboratory that can search, rank, demote and revise cosmic-intent candidates.",
            R="Ultimate existence claim blocked; operational mission vector supported as a robust action construct.",
        ),
        SemanticObject(
            name="DIKWP semantic collapse",
            D="Intent-driven transformation of DIKWP content.",
            I="Concept space and semantic space affect each other bidirectionally.",
            K="De-falsification, de-redundancy, conflict exposure, residual preservation, standard-as-object audit.",
            W="Avoid overcollapse, dogma and premature unity.",
            P="Turn candidate cosmic purposes into auditable semantic objects.",
            R="Supported as local system mechanism; not external cosmic proof.",
        ),
    ]
