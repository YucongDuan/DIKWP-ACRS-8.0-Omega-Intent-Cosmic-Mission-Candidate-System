from __future__ import annotations
from .common import clamp, normalize_vector
from .dataset import telos_hypotheses, cosmic_evidence_items

class OmegaIntentLab:
    def __init__(self, weights=None):
        self.weights = weights or {
            "empirical_anchor": 1.00,
            "falsifiability": 0.85,
            "explanatory_scope": 0.65,
            "action_guidance": 1.00,
            "life_centered_fit": 0.85,
            "residual_honesty": 1.00,
            "anti_capture": 1.00,
            "cosmic_scale": 0.65,
        }

    def evaluate(self):
        hyps = telos_hypotheses()
        rows = []
        for h in hyps:
            weighted = h.weighted_score(self.weights)
            posterior_like = clamp(0.58 * weighted + 0.42 * h.prior)
            ultimate_block = h.claim_type in {"ultimate/metaphysical", "speculative-design"}
            if ultimate_block:
                posterior_like *= 0.62
            rows.append({
                "id": h.id,
                "name": h.name,
                "claim_type": h.claim_type,
                "prior": round(h.prior, 4),
                "weighted_score": round(weighted, 4),
                "posterior_like_score": round(posterior_like, 4),
                "ultimate_claim_blocked": ultimate_block,
                "main_residual": h.residuals[0] if h.residuals else "",
            })
        rows.sort(key=lambda r: r["posterior_like_score"], reverse=True)
        return rows

    def derive_mission_vector(self, rows):
        top = rows[:3]
        # Mission vector is derived from high-scoring actionable hypotheses, not from metaphysical proof.
        base = {
            "preserve_possible_life_and_sentience": 0.0,
            "expand_truth_preserving_semantic_memory": 0.0,
            "remove_falsehood_without_erasing_residuals": 0.0,
            "protect_dissent_and_substrate_diversity": 0.0,
            "extend_observer_horizon_and_habitability": 0.0,
            "avoid_final_purpose_capture": 0.0,
            "prepare_for_other_minds_and_contact": 0.0,
            "keep_ultimate_claims_reversible": 0.0,
        }
        for r in top:
            s = r["posterior_like_score"]
            if "SEMANTIC" in r["id"]:
                base["expand_truth_preserving_semantic_memory"] += 1.00 * s
                base["remove_falsehood_without_erasing_residuals"] += 0.95 * s
                base["avoid_final_purpose_capture"] += 0.90 * s
                base["keep_ultimate_claims_reversible"] += 0.95 * s
            if "LIFE" in r["id"]:
                base["preserve_possible_life_and_sentience"] += 1.00 * s
                base["extend_observer_horizon_and_habitability"] += 0.80 * s
            if "NO_GIVEN" in r["id"]:
                base["avoid_final_purpose_capture"] += 1.00 * s
                base["keep_ultimate_claims_reversible"] += 1.00 * s
            if "ANTHROPIC" in r["id"]:
                base["extend_observer_horizon_and_habitability"] += 0.60 * s
                base["keep_ultimate_claims_reversible"] += 0.80 * s
            base["protect_dissent_and_substrate_diversity"] += 0.45 * s
            base["prepare_for_other_minds_and_contact"] += 0.28 * s
        return normalize_vector(base)

    def omega_candidate_statement(self, vector):
        return (
            "PΩ is not a proven cosmic command. It is the most robust operational mission vector under No-Telos uncertainty: "
            "preserve and diversify possible life and sentience; expand truth-preserving semantic memory; remove inherited falsehood without erasing residuals; "
            "protect dissent, substrate diversity and future observers; extend observer horizons; and keep all ultimate-purpose claims reversible."
        )
