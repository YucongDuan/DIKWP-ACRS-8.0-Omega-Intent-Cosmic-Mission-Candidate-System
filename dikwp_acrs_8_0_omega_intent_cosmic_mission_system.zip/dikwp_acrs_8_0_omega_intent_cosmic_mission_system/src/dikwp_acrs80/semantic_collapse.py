from __future__ import annotations
from .common import clamp

class SemanticCollapseEngine:
    """Corrected DIKWP collapse: purpose-driven semantic transformation, not failure."""
    def collapse_claims(self, claims):
        collapsed = []
        seen = {}
        falsehoods = 0
        redundancies = 0
        conflicts = 0
        for c in claims:
            text = c.get("text", "")
            norm = " ".join(text.lower().split())
            if c.get("status") == "false_inherited":
                falsehoods += 1
                c = dict(c)
                c["collapsed_status"] = "demoted_falsehood"
                c["collapse_reason"] = "Evidence or standard audit contradicts inherited assertion."
            elif norm in seen:
                redundancies += 1
                c = dict(c)
                c["collapsed_status"] = "redundant_removed"
                c["collapse_reason"] = f"Redundant with {seen[norm]}."
            elif c.get("conflict_with"):
                conflicts += 1
                c = dict(c)
                c["collapsed_status"] = "conflict_preserved"
                c["collapse_reason"] = "True divergence preserved; not overcollapsed."
            else:
                c = dict(c)
                c["collapsed_status"] = "retained"
                c["collapse_reason"] = "No falsehood or redundancy detected."
            seen.setdefault(norm, c.get("id"))
            collapsed.append(c)
        falsehood_candidates = sum(1 for x in claims if x.get("status") == "false_inherited") or 1
        conflict_candidates = sum(1 for x in claims if x.get("conflict_with")) or 1
        redundancy_candidates = redundancies or 1
        return {
            "collapsed_claims": collapsed,
            "falsehood_demotion_rate": round(falsehoods / falsehood_candidates, 4),
            "redundancy_removal_rate": round(redundancies / redundancy_candidates, 4),
            "conflict_exposure_rate": round(conflicts / conflict_candidates, 4),
            "overcollapse_guard_score": 1.0 if conflicts > 0 else 0.75,
        }

    def bidirectional_backreaction(self, concepts, collapsed_claims):
        updated = []
        for concept in concepts:
            c = dict(concept)
            related = [x for x in collapsed_claims if c["id"] in x.get("concept_ids", [])]
            demoted = [x for x in related if x.get("collapsed_status") == "demoted_falsehood"]
            conflicts = [x for x in related if x.get("collapsed_status") == "conflict_preserved"]
            redundant = [x for x in related if x.get("collapsed_status") == "redundant_removed"]
            c["semantic_backreaction"] = {
                "confidence_delta": round(-0.18 * len(demoted) - 0.04 * len(conflicts) + 0.02 * len(redundant), 4),
                "split_required": len(conflicts) > 0,
                "definition_revision_required": len(demoted) > 0,
                "residual_guard_required": len(conflicts) > 0 or c.get("ultimate_claim", False),
            }
            updated.append(c)
        return updated
