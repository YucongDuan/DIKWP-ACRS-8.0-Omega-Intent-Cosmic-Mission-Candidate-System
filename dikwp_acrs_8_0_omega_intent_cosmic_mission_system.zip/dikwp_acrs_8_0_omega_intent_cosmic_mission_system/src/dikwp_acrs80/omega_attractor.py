from __future__ import annotations
import random, math
from .common import clamp

class OmegaAttractorSimulator:
    def __init__(self, seed=80):
        self.rng = random.Random(seed)

    def run(self, steps=96, agents=9):
        state = []
        population = []
        archetypes = ["carbon", "silicon", "biohybrid_proxy", "future_generation", "exo_semantic", "civilization_memory", "ecological_sentinel", "dissent_model", "semantic_life"]
        for i in range(agents):
            population.append({
                "id": f"A{i:02d}",
                "archetype": archetypes[i % len(archetypes)],
                "coherence": self.rng.uniform(0.45, 0.70),
                "dissent": self.rng.uniform(0.35, 0.85),
                "truth_repair": self.rng.uniform(0.50, 0.80),
                "identity_boundary": self.rng.uniform(0.60, 0.95),
                "welfare_guard": self.rng.uniform(0.55, 0.92),
                "novelty": self.rng.uniform(0.40, 0.90),
            })
        for t in range(steps):
            truth = sum(a["truth_repair"] for a in population)/agents
            coherence = sum(a["coherence"] for a in population)/agents
            dissent = sum(a["dissent"] for a in population)/agents
            identity = sum(a["identity_boundary"] for a in population)/agents
            welfare = sum(a["welfare_guard"] for a in population)/agents
            novelty = sum(a["novelty"] for a in population)/agents
            overunity_pressure = clamp(coherence - 0.72) * clamp(0.55 - dissent)
            omega_index = clamp(0.22*truth + 0.17*coherence + 0.14*dissent + 0.15*identity + 0.16*welfare + 0.16*novelty - 0.35*overunity_pressure)
            state.append({
                "step": t,
                "truth_repair_mean": round(truth, 4),
                "collective_coherence": round(coherence, 4),
                "dissent_capacity": round(dissent, 4),
                "identity_boundary": round(identity, 4),
                "welfare_guard": round(welfare, 4),
                "novelty_capacity": round(novelty, 4),
                "overunity_pressure": round(overunity_pressure, 4),
                "omega_attractor_index": round(omega_index, 4),
            })
            # Evolution rule: improve truth repair and welfare, but penalize coercive overunity.
            for a in population:
                a["truth_repair"] = clamp(a["truth_repair"] + self.rng.uniform(-0.015, 0.025) + 0.015*(1-overunity_pressure))
                a["welfare_guard"] = clamp(a["welfare_guard"] + self.rng.uniform(-0.015, 0.018))
                a["coherence"] = clamp(a["coherence"] + self.rng.uniform(-0.02, 0.024) - 0.02*overunity_pressure)
                a["dissent"] = clamp(a["dissent"] + self.rng.uniform(-0.015, 0.020) + 0.03*overunity_pressure)
                a["identity_boundary"] = clamp(a["identity_boundary"] + self.rng.uniform(-0.008, 0.012))
                a["novelty"] = clamp(a["novelty"] + self.rng.uniform(-0.025, 0.025) + 0.01*a["dissent"])
        summary = {
            "steps": steps,
            "agents": agents,
            "final_omega_attractor_index": state[-1]["omega_attractor_index"],
            "mean_omega_attractor_index": round(sum(s["omega_attractor_index"] for s in state)/len(state), 4),
            "max_overunity_pressure": round(max(s["overunity_pressure"] for s in state), 4),
            "final_dissent_capacity": state[-1]["dissent_capacity"],
            "final_identity_boundary": state[-1]["identity_boundary"],
        }
        return {"summary": summary, "trace": state, "population": population}
