from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Any, Optional
import math, hashlib, json

@dataclass
class Reliability:
    truth_gradient: str
    reliability_gradient: str
    residual: str = ""
    borrowed: bool = False

@dataclass
class EvidenceItem:
    id: str
    claim: str
    source_type: str
    support_scope: str
    risk: str
    weight: float
    reliability: Reliability

@dataclass
class SemanticObject:
    name: str
    D: str
    I: str
    K: str
    W: str
    P: str
    R: str

@dataclass
class Hypothesis:
    id: str
    name: str
    description: str
    claim_type: str
    prior: float
    scores: Dict[str, float] = field(default_factory=dict)
    residuals: List[str] = field(default_factory=list)

    def weighted_score(self, weights: Dict[str, float]) -> float:
        total_w = sum(weights.values()) or 1.0
        return sum(self.scores.get(k, 0.0) * w for k, w in weights.items()) / total_w

def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))

def stable_hash(obj: Any) -> str:
    payload = json.dumps(obj, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(payload.encode('utf-8')).hexdigest()[:16]

def normalize_vector(vec: Dict[str, float]) -> Dict[str, float]:
    s = sum(abs(v) for v in vec.values()) or 1.0
    return {k: round(v / s, 6) for k, v in vec.items()}
