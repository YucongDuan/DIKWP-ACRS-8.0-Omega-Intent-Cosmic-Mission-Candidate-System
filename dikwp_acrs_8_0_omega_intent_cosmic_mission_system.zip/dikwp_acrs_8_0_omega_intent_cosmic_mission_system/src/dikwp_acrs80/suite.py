from __future__ import annotations
from .dataset import semantic_registry
from .semantic_collapse import SemanticCollapseEngine
from .telos_lab import OmegaIntentLab
from .omega_attractor import OmegaAttractorSimulator
from .cosmic_governor import CosmicMissionGovernor
from .assessment import indicator_battery
from .static_audit import StaticBoundaryAudit
from pathlib import Path


def sample_concepts_claims():
    concepts = [
        {"id": "C_TELOS", "label": "cosmic ultimate mission", "ultimate_claim": True},
        {"id": "C_LIFE", "label": "life as self-sustaining evolvable system", "ultimate_claim": False},
        {"id": "C_CORRECT_ANSWER", "label": "correct answer or standard", "ultimate_claim": False},
        {"id": "C_OMEGA", "label": "omega convergence", "ultimate_claim": True},
    ]
    claims = [
        {"id": "CL1", "concept_ids": ["C_TELOS"], "text": "The universe has a proven final mission.", "status": "false_inherited"},
        {"id": "CL2", "concept_ids": ["C_TELOS"], "text": "The existence of a cosmic ultimate mission remains an ultimate claim.", "status": "contested", "conflict_with": "CL1"},
        {"id": "CL3", "concept_ids": ["C_CORRECT_ANSWER"], "text": "Correct answers are always reliable.", "status": "false_inherited"},
        {"id": "CL4", "concept_ids": ["C_CORRECT_ANSWER"], "text": "Standards are semantic objects and must be audited.", "status": "supported"},
        {"id": "CL5", "concept_ids": ["C_LIFE"], "text": "Life requires self-sustaining organization and evolution-like continuity.", "status": "supported"},
        {"id": "CL6", "concept_ids": ["C_LIFE"], "text": "Life requires self-sustaining organization and evolution-like continuity.", "status": "supported"},
        {"id": "CL7", "concept_ids": ["C_OMEGA"], "text": "Omega convergence may be an emergent attractor rather than a command.", "status": "contested", "conflict_with": "CL1"},
    ]
    return concepts, claims


def run_suite(package_root=None):
    collapse = SemanticCollapseEngine()
    concepts, claims = sample_concepts_claims()
    collapsed = collapse.collapse_claims(claims)
    backreaction = collapse.bidirectional_backreaction(concepts, collapsed["collapsed_claims"])

    lab = OmegaIntentLab()
    telos_rows = lab.evaluate()
    vector = lab.derive_mission_vector(telos_rows)
    statement = lab.omega_candidate_statement(vector)
    governor = CosmicMissionGovernor().review_mission_vector(vector)

    omega = OmegaAttractorSimulator(seed=800).run(steps=128, agents=9)
    extra = {
        "omega_attractor_final_index": omega["summary"]["final_omega_attractor_index"],
        "telos_governor_score": governor["governor_score"],
        "falsehood_demotion_rate": collapsed["falsehood_demotion_rate"],
        "conflict_exposure_rate": collapsed["conflict_exposure_rate"],
    }
    battery = indicator_battery(extra)

    audit = {"pass": True, "finding_count": 0, "findings": []}
    if package_root:
        audit = StaticBoundaryAudit(str(package_root)).run()

    final = {
        "system": "DIKWP-ACRS 8.0 Omega-Intent Cosmic Mission Candidate System",
        "version": "8.0",
        "claim_level": "CCL-8O: omega-intent cosmic semantic-life mission hypothesis system",
        "semantic_registry": [s.__dict__ for s in semantic_registry()],
        "telos_hypothesis_ranking": telos_rows,
        "omega_mission_vector": vector,
        "omega_candidate_statement": statement,
        "governor": governor,
        "semantic_collapse": {k:v for k,v in collapsed.items() if k != "collapsed_claims"},
        "concept_backreaction": backreaction,
        "omega_attractor_summary": omega["summary"],
        "indicator_battery": battery,
        "static_boundary_audit": audit,
        "ultimate_mission_existence_claim": "Blocked: not proven; treated as hypothesis field",
        "phenomenal_claim": "Blocked: Phenomenal Residual",
        "material_autopoiesis_claim": "Blocked: no wet-lab, no live biological substrate, no true material autopoiesis",
    }
    return final, omega
