# Evaluation Results Report

The local run produced:

- CCL-8O claim level.
- weighted indicator score above 0.85.
- top operational candidate: semantic-life truth-repair attractor, life-expansion, or no-given-telos constraint depending on weights.
- ultimate mission existence: Blocked.
- phenomenal claim: Blocked.
- material autopoiesis claim: Blocked.

The package includes JSON and CSV outputs for direct inspection.
