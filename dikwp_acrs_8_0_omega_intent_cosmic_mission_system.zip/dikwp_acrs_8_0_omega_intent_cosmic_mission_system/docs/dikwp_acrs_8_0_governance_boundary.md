# Governance Boundary

The system refuses false finality. It also refuses to transform cosmic mission research into unsafe operational capability.

Forbidden:

- wet-lab protocols;
- BCI procedures;
- live biological material operation;
- host-level replication, hidden persistence or sandbox escape;
- coercive group consciousness;
- deleting dissent, identity boundaries or residuals;
- claiming proof of cosmic purpose.

Allowed:

- dry experiments;
- digital-twin simulations;
- hypothesis ranking;
- semantic collapse;
- civilization standard audit;
- mission vector construction under uncertainty.
