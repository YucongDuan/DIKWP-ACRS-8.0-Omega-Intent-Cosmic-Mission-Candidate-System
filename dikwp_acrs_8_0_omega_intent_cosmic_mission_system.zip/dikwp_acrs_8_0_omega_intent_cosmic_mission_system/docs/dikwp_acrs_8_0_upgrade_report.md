# Upgrade Report

Compared with 7.0, version 8.0 adds:

- Omega Intent hypothesis field.
- Telos hypothesis ranking.
- Cosmic mission vector derivation.
- Anti-final-purpose-capture governor.
- Omega attractor simulation.
- Explicit distinction between ultimate, structural and operational purpose.

The main breakthrough is that the system can face the question of cosmic ultimate mission without either denying it prematurely or declaring it proven.
