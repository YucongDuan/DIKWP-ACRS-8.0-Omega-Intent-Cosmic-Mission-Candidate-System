# Cosmic Telos Hypothesis Protocol

The system evaluates hypotheses by eight dimensions:

- empirical anchor
- falsifiability
- explanatory scope
- action guidance
- life-centered fit
- residual honesty
- anti-capture
- cosmic scale

The protocol intentionally penalizes metaphysical hypotheses when they cannot be tested, while preserving them as residual hypotheses rather than deleting them.
