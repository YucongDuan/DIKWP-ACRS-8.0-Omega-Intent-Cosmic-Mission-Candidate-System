# Evidence Ledger Template

| ID | Claim | Source Type | Support Scope | Does Not Support | Risk | Reliability | Kill |
|---|---|---|---|---|---|---|---|
| E1 |  | User / Attachment / External / Tool / Prior / Unknown |  |  |  | Solid / Supported / Provisional / Borrowed / Contested / Blocked |  |
