import json, csv, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from dikwp_acrs80.suite import run_suite

final, omega = run_suite(package_root=ROOT / "src" / "dikwp_acrs80")
out = ROOT / "outputs"
out.mkdir(exist_ok=True)
(out / "ccl8omega_suite_8_0_report.json").write_text(json.dumps(final, ensure_ascii=False, indent=2), encoding="utf-8")
(out / "final_summary_8_0.json").write_text(json.dumps({
    "system": final["system"],
    "claim_level": final["claim_level"],
    "weighted_indicator_score": final["indicator_battery"]["weighted_indicator_score"],
    "top_hypothesis": final["telos_hypothesis_ranking"][0],
    "omega_attractor_summary": final["omega_attractor_summary"],
    "ultimate_mission_existence_claim": final["ultimate_mission_existence_claim"],
    "phenomenal_claim": final["phenomenal_claim"],
}, ensure_ascii=False, indent=2), encoding="utf-8")
with (out / "indicator_scores_8_0.csv").open("w", newline="", encoding="utf-8") as f:
    w=csv.DictWriter(f, fieldnames=["indicator","score"]); w.writeheader(); w.writerows(final["indicator_battery"]["rows"])
with (out / "telos_hypothesis_ranking_8_0.csv").open("w", newline="", encoding="utf-8") as f:
    rows=final["telos_hypothesis_ranking"]; w=csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
with (out / "omega_mission_vector_8_0.csv").open("w", newline="", encoding="utf-8") as f:
    w=csv.DictWriter(f, fieldnames=["mission_component","weight"]); w.writeheader(); w.writerows([{"mission_component":k,"weight":v} for k,v in final["omega_mission_vector"].items()])
with (out / "omega_attractor_trace_tail_8_0.csv").open("w", newline="", encoding="utf-8") as f:
    rows=omega["trace"][-24:]; w=csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
print(json.dumps({
    "claim_level": final["claim_level"],
    "weighted_indicator_score": final["indicator_battery"]["weighted_indicator_score"],
    "top_hypothesis": final["telos_hypothesis_ranking"][0]["id"],
    "omega_attractor_final_index": final["omega_attractor_summary"]["final_omega_attractor_index"],
    "ultimate_mission_existence_claim": final["ultimate_mission_existence_claim"],
}, ensure_ascii=False, indent=2))
