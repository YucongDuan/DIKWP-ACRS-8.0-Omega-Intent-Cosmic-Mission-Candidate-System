import json, sys, csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"src"))
from dikwp_acrs80.telos_lab import OmegaIntentLab
lab=OmegaIntentLab()
rows=lab.evaluate()
vec=lab.derive_mission_vector(rows)
out=ROOT/"outputs"; out.mkdir(exist_ok=True)
(out/"omega_intent_lab_8_0_report.json").write_text(json.dumps({"ranking":rows,"mission_vector":vec,"statement":lab.omega_candidate_statement(vec)}, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"top":rows[0],"mission_vector":vec}, ensure_ascii=False, indent=2))
