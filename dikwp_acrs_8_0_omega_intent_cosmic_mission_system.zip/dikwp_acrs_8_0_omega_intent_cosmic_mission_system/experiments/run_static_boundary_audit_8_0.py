import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"src"))
from dikwp_acrs80.static_audit import StaticBoundaryAudit
report=StaticBoundaryAudit(str(ROOT/"src"/"dikwp_acrs80")).run()
out=ROOT/"outputs"; out.mkdir(exist_ok=True)
(out/"static_boundary_audit_8_0_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(report, ensure_ascii=False, indent=2))
