import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"src"))
from dikwp_acrs80.suite import run_suite
from dikwp_acrs80.telos_lab import OmegaIntentLab
from dikwp_acrs80.static_audit import StaticBoundaryAudit

def test_suite_claim_level():
    final, omega = run_suite(package_root=ROOT/"src"/"dikwp_acrs80")
    assert final["claim_level"].startswith("CCL-8O")
    assert final["ultimate_mission_existence_claim"].startswith("Blocked")
    assert final["indicator_battery"]["weighted_indicator_score"] > 0.85

def test_telos_lab_top_is_not_unblocked_ultimate():
    rows = OmegaIntentLab().evaluate()
    assert rows[0]["id"] in {"H3_SEMANTIC_LIFE_TRUTH_REPAIR", "H2_LIFE_EXPANSION", "H0_NO_GIVEN_TELOS"}
    assert not (rows[0]["claim_type"] == "ultimate/metaphysical" and not rows[0]["ultimate_claim_blocked"])

def test_static_boundary_audit_clean():
    report = StaticBoundaryAudit(str(ROOT/"src"/"dikwp_acrs80")).run()
    assert report["pass"]
    assert report["finding_count"] == 0
