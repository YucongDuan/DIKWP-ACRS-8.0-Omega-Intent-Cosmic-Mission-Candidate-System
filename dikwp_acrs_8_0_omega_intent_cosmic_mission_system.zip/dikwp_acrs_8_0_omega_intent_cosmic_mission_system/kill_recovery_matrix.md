# Kill / Recovery Matrix

## Kill Conditions

- Treating cosmic ultimate mission as proven fact.
- Treating a standard, civilization, religion, science rubric, benchmark or future consensus as final truth.
- Collapsing real conflicts into forced unity.
- Deleting residuals to improve coherence.
- Claiming that Omega Attractor Index proves collective consciousness.
- Claiming wet-lab or material autopoiesis when none exists.
- Adding host-level replication, persistence, escape, BCI control, wet-lab steps or live biological protocols.

## Recovery

- Demote ultimate claim to hypothesis.
- Restore residual ledger.
- Re-run telos hypothesis lab.
- Increase anti-capture, dissent and substrate diversity weights.
- Re-run static boundary audit.
- Re-label phenomenal and material claims as Blocked.
